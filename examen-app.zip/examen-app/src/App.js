// App.js

import React, { useState } from 'react';
import Entrada from './components/Entrada';
import './styles/entrada.css';

const App = () => {
  const [entradas, setEntradas] = useState([]);

  const handleGuardarEntrada = (nuevaEntrada) => {
    setEntradas([...entradas, nuevaEntrada]);
  };

  return (
    <div>
      <h1>APLICACION DE ENTRADAS</h1>
      <h4>EXAMEN TECNICO NODE JS </h4>
      <h6>- Christian J. de los Santos Hidalgo</h6>

      <Entrada onGuardarEntrada={handleGuardarEntrada} />

    </div>
  );
};

export default App;
