import React, { useState } from 'react';

const Entrada = ({ onGuardarEntrada }) => {
  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [fecha, setFecha] = useState('');
  const [contenido, setContenido] = useState('');
  const [busqueda, setBusqueda] = useState('');
  const [entradas, setEntradas] = useState([]);
  const [entradaSeleccionada, setEntradaSeleccionada] = useState(null);
  const [error, setError] = useState('');

  const handleGuardarEntrada = () => {
    if (!titulo || !autor || !fecha || !contenido) {
        setError('Todos los campos son obligatorios');
        return;
      }
  
      // Validar el formato de la fecha
      const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!fecha.match(fechaRegex)) {
        setError('Formato de fecha no válido. Utiliza YYYY-MM-DD');
        return;
      }


    const nuevaEntrada = {
      titulo,
      autor,
      fecha,
      contenido,
    };
    setEntradas([...entradas, nuevaEntrada]);
    // Puedes reiniciar los campos aquí si es necesario
    setTitulo('');
    setAutor('');
    setFecha('');
    setContenido('');
    setError('');
  };

  const filtrarEntradas = () => {
    return entradas.filter(
      (entrada) =>
        entrada.titulo.toLowerCase().includes(busqueda.toLowerCase()) ||
        entrada.autor.toLowerCase().includes(busqueda.toLowerCase()) ||
        entrada.contenido.toLowerCase().includes(busqueda.toLowerCase())
    );
  };

  const mostrarDetalle = (index) => {
    setEntradaSeleccionada(entradas[index]);
  };

  const cerrarModal = () => {
    setEntradaSeleccionada(null);
  };

  return (
    <div className='contenedor'>
    <div>
      <label className='titulo'>Título:</label>
      <div className='inptitulo'><input  type="text" value={titulo} onChange={(e) => setTitulo(e.target.value)} /></div>

      <label className='autor'>Autor:</label>
      <div className='inpautor'><input  type="text" value={autor} onChange={(e) => setAutor(e.target.value)} /></div>

      <label className='fecha'>Fecha de publicación:</label>
      <div className='inpfecha'><input  type="text" value={fecha} onChange={(e) => setFecha(e.target.value)} /></div>

      <label className='contenido'>Contenido:</label>
      <div className='textcontenido'><textarea  value={contenido} onChange={(e) => setContenido(e.target.value)} /></div>

      <button onClick={handleGuardarEntrada}>Guardar Entrada</button>

      <span className="error">{error}</span>

      <input
        className='buscar'
        type="text"
        placeholder="Buscar por título, autor o contenido"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />

      <ul>
        {filtrarEntradas().map((entrada, index) => (
          <li key={index} onClick={() => mostrarDetalle(index)}>
            <strong>{entrada.titulo}</strong> - {entrada.autor} - {entrada.fecha}
            <p>{entrada.contenido.slice(0, 50)}...</p>
          </li>
        ))}
      </ul>

      {entradaSeleccionada && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={cerrarModal}>&times;</span>
            <h2>{entradaSeleccionada.titulo}</h2>
            <p>Autor: {entradaSeleccionada.autor}</p>
            <p>Fecha: {entradaSeleccionada.fecha}</p>
            <p>{entradaSeleccionada.contenido}</p>
          </div>
        </div>
      )}
    </div>
    </div>
  );
};

export default Entrada;
